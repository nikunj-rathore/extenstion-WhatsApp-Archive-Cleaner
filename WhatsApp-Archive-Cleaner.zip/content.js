console.log('%c WA EXTENSION LOADED ', 'background: #25d366; color: white; font-size: 20px;');

/**
 * ---------------------------------------------------------
 * CATEGORY 0: SUPER UTILITIES (Forced Interaction)
 * ---------------------------------------------------------
 */

async function smartClick(el) {
  if (!el) return;

  el.scrollIntoView({
    behavior: 'smooth',
    block: 'center'
  });

  await sleep(500);

  ['mousedown', 'mouseup', 'click'].forEach(eventType => {
    el.dispatchEvent(
      new MouseEvent(eventType, {
        bubbles: true,
        view: window
      })
    );
  });
}




chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === 'start_cleaning') {
    startCleaning();
    sendResponse({ status: 'Cleaning started' });
  }
  return true;
});




async function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}






/**
 * Helper: Send error message to Popup UI
 */
function reportError(msg) {
  console.error(msg);
  chrome.runtime.sendMessage({ action: 'show_error', message: msg }).catch(() => {});
}




/**
 * ---------------------------------------------------------
 * CATEGORY 2: ARCHIVE CLEANING LOGIC (Restored with Error Handling)
 * ---------------------------------------------------------
 */
async function startCleaning() {
  console.log('%c STARTING ORIGINAL ARCHIVE CLEANER ', 'background: #075e54; color: white;');

  // --- STEP 1: ARCHIVED FOLDER KE ANDAR JANA ---
  let archivedBtn = document.querySelector('span[aria-label="Archived"]') || 
                    document.querySelector('button[aria-label="Archived"]') ||
                    Array.from(document.querySelectorAll('span')).find(el => el.textContent === 'Archived');
  
  if (archivedBtn) {
    console.log('Archived folder par click ho raha hai...');
    await smartClick(archivedBtn);
    await sleep(2000); 
  } else {
    reportError('Archive Folder not found on sidebar.');
    return;
  }

  // --- STEP 2: CHATS KI LIST DHUNDHNA ---
  const chatList = document.querySelectorAll('div[role="listitem"]');
  console.log(`Found ${chatList.length} chats.`);

  if (chatList.length === 0) {
    reportError('No archived chats found.');
    return;
  }

  for (let i = 0; i < chatList.length; i++) {
    const chat = chatList[i];
    chat.scrollIntoView(); 
    await sleep(500);

    // --- STEP 3: CHAT KO SELECT/OPEN KARNA ---
    console.log(`Chat ${i + 1} ko open kiya ja raha hai...`);
    const targets = [
      chat.querySelector('span[title]'), 
      chat.querySelector('div[role="gridcell"]'), 
      chat 
    ];

    let clicked = false;
    for (const target of targets) {
      if (target) {
        await smartClick(target);
        clicked = true;
        break;
      }
    }

    if (!clicked) {
      reportError(`Could not click chat item ${i + 1}`);
      continue;
    }

    await sleep(2000); 

    // --- STEP 4: 3-DOT MENU SELECT KARNA (Header me) ---
    console.log(`Chat ${i + 1} finding menu...`);
    let menuBtn = null;
    const headers = document.querySelectorAll('header');
    let activeHeader = null;
    
    for (const h of headers) {
      if (h.closest('#main') || h.querySelector('[data-testid="conversation-info-header"]')) {
        activeHeader = h;
        break;
      }
    }
    
    if (activeHeader) {
      menuBtn = activeHeader.querySelector('[data-testid="menu"]') || 
                activeHeader.querySelector('[data-icon="menu"]') ||
                activeHeader.querySelector('[aria-label*="Menu"]');
    }

    if (menuBtn) {
      console.log('Menu button mil gaya, click ho raha hai...');
      await smartClick(menuBtn);
      await sleep(1000); 

      // --- STEP 5: CLEAR CHAT OPTION SELECT KARNA ---
      const allElements = document.querySelectorAll('div, span, li');
      
      const visibleElements = Array.from(allElements).filter(el =>
        el.offsetParent !== null
      );
      
      let clearOption =
        visibleElements.find(el =>
          el.textContent.trim().toLowerCase() === 'delete chat'
        ) ||
        visibleElements.find(el =>
          el.textContent.trim().toLowerCase() === 'clear chat'
        ) ||
        visibleElements.find(el =>
          el.textContent.trim().toLowerCase() === 'clear messages'
        );

      if (clearOption) {
        console.log('Clear option mil gaya, click ho raha hai...');
        await smartClick(clearOption);
        await sleep(1000);

        // --- STEP 6: CONFIRMATION MODAL ME CLEAR PAR CLICK KARNA ---
        const modalButtons = document.querySelectorAll('button');
        
        const confirmBtn = Array.from(modalButtons).find(el => {
          const text = el.textContent.trim().toLowerCase();
        
          return (
            text.includes('delete') ||
            text.includes('clear')
          ) && !text.includes('cancel');
        });

        
        if (confirmBtn) {
          console.log('Clearing confirm ho rahi hai...');
          await smartClick(confirmBtn);
          await sleep(3000); 
        } else {
          reportError(`Confirmation button not found for chat ${i + 1}`);
        }
      } else {
        reportError(`'Clear Chat' option not found in menu for chat ${i + 1}`);
      }
    } else {
      reportError(`Menu button (3 dots) not found for chat ${i + 1}`);
    }

    await sleep(2000); 
  }

  alert('Archive clearing process complete!');
}






window.addEventListener('load', async () => {
  await sleep(3000);
  createFloatingPanel();
});




function createFloatingPanel() {
  if (document.getElementById('wa-helper-panel')) return;
  const panel = document.createElement('div');
panel.id = 'wa-helper-panel';
  panel.innerHTML = `
<div id="wa-header" style="
  background:#075e54;
  color:white;
  padding:8px;
  display:flex;
  justify-content:space-between;
  align-items:center;
">
  <span>WA Helper</span>

  <div>
    <button id="wa-min">−</button>
    <button id="wa-max">□</button>
  </div>
</div>

<iframe
  src="${chrome.runtime.getURL('popup.html')}"
  style="
    width:100%;
    height:calc(100% - 40px);
    border:none;
  ">
</iframe>
`;

  panel.style.cssText = `
    position: fixed;
    top: 20px;
    right: 20px;
    width: 300px;
    height: 600px;
    z-index: 999999;
    background: white;
    border-radius: 10px;
    box-shadow: 0 0 20px rgba(0,0,0,.3);
    resize: both;
    overflow: auto;
  `;

  document.body.appendChild(panel);
  const iframe = panel.querySelector('iframe');

document.getElementById('wa-min').onclick = () => {
  if (iframe.style.display === 'none') {
    iframe.style.display = 'block';
    panel.style.height = '600px';
  } else {
    iframe.style.display = 'none';
    panel.style.height = '40px';
  }
};

let maximized = false;

document.getElementById('wa-max').onclick = () => {
  if (!maximized) {
    panel.style.width = '600px';
    panel.style.height = '90vh';
    panel.style.top = '10px';
    panel.style.right = '10px';
    maximized = true;
  } else {
    panel.style.width = '300px';
    panel.style.height = '600px';
    panel.style.top = '20px';
    panel.style.right = '20px';
    maximized = false;
  }
};
}