document.getElementById('start-btn').addEventListener('click', () => {
  sendMessageToContent({ action: 'start_cleaning' });
});




/**
 * HELPER: COMMUNICATION
 */
async function sendMessageToContent(payload) {
  const status = document.getElementById('status');
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  
  if (!tab || !tab.url.includes('web.whatsapp.com')) {
    status.textContent = 'Open WhatsApp Web first';
    return;
  }

  chrome.tabs.sendMessage(tab.id, payload, (response) => {
    if (chrome.runtime.lastError) {
      status.textContent = 'Error: Refresh WhatsApp';
    } else {
      status.textContent = response?.status || 'Process active...';
    }
  });
}

